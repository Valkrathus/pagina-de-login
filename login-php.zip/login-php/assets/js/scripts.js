// *Botões de menu*
// Variável para armazenar id do botão
let targetName = null;
// Variável para armazenar o nome do menu
let targetMenu = null;


// Função para abrir os formulários
function openMenu(buttonId){
    // Armazena o id do botão apertado
    targetName  = buttonId;
    // Define o menu
    targetMenu = targetName.replace('button-' , '#menu-');

    // Animações para exibir o formulário selecionado
    document.querySelector('#menu-main').style.opacity = '0';
    document.querySelector(targetMenu).style.visibility = 'visible';
    setTimeout(function() {
        document.querySelector('#menu-main').style.height = '0';
        document.querySelector(targetMenu).style.opacity = '1';
        document.querySelector(targetMenu).style.height = '100%';
    }, 10);
    setTimeout(function() {
        document.querySelector('#menu-main').style.visibility = 'hidden';
    }, 510);
}

// Função retornar ao menu principal
function closeMenu(){
    // Animações para exibir o formulário selecionado
    document.querySelector(targetMenu).style.opacity = '0';
    document.querySelector('#menu-main').style.visibility = 'visible';
    setTimeout(function() {
        document.querySelector(targetMenu).style.height = '0';
        document.querySelector('#menu-main').style.opacity = '1';
        document.querySelector('#menu-main').style.height = '100%';
    }, 10);
    setTimeout(function() {
        document.querySelector(targetMenu).style.visibility = 'hidden';
    }, 510);
}



// *Formulários*
// Adiciona triggers para quando o formulário for enviado
document.querySelector('#form-cadastro').addEventListener('submit', submitFormHandler);
document.querySelector('#form-login').addEventListener('submit', submitFormHandler);
document.querySelector('#form-recuperar').addEventListener('submit', submitFormHandler);
function submitFormHandler(event) {
    // Cancela o envio do formulário
    event.preventDefault();
  
    // Captura os dados do formulário
    let data = new FormData(event.target);
  
    // Converte os dados para uma forma legível
    let value = Object.fromEntries(data.entries());

    // Mostra os dados do formuláro no formato "nome do campo":"valor" no console
    console.log({ value });
    // Transforma os dados do formulário em string e os mostra os no formato "nome do campo":"valor" em uma popup
    alert(JSON.stringify(value));
}