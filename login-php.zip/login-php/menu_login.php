<div class="title">
    <button onClick="closeMenu()" class="button-primary-round">
        <i class="fas fa-angle-left"></i>
    </button>
    <h1> Login </h1>
</div>
<form action="." method="post" id="form-login">

    <div class="form-field"> 
        <div class="form-icon">
            <i class="fas fa-envelope"></i>
        </div>
        <input
            type="email"
            name="form-login-email"
            id="login-email"
            placeholder="ex.: email@site.com"
            title="Deve seguir o formato nome@domínio.extensão do domínio, e ter no mínimo de 11 caracteres, ou um máximo de 35"
            minlength="11"
            maxlength="35"
            required
        >
    </div>

    <div class="form-field"> 
        <div class="form-icon">
            <i class="fas fa-unlock-alt"></i>
        </div>
        <input
            type="password"
            name="form-login-senha"
            id="login-senha"
            placeholder="**********"
            minlength="7"
            maxlength="25"
            pattern="(?=^.{7,25}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$"
            title = "Deve conter no mínimo uma letra maiuscula, uma minuscula, um número, um caractere especial, e ter no mínimo de 7 caracteres, ou um máximo de 25"
            required
        >
    </div>

    <input type="submit" value="Acessar" class="button-primary">
</form>