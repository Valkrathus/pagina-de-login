<div class="container-copy">
    <div class="copy-link">
        <a href="https://unsplash.com/pt-br/@marekpiwnicki" target="_blank" style="margin-bottom: 10px;"> <i class="fas fa-camera"></i> Marek Piwnicki | Unsplash </a>
        <a href="https://br.freepik.com/vetores-gratis/amo-a-ilustracao-de-design-gradiente-de-luxo-de-logotipo_32185137.htm#query=placeholder%20logo&position=2&from_view=search&track=ais&uuid=285d5e92-1adb-4c32-bd75-b660b0c20588" target="_blank"> <i class="fas fa-paint-brush"></i> AndreaCharlesta | Freepik </a>
    </div>
</div>

<div class="container-footer">
    <p> <a href="https://creativecommons.org/publicdomain/zero/1.0/deed.en" target="_blank">CC0 1.0 Universal <i class="fab fa-creative-commons-zero"></i></a>&nbsp; 2024 - <a href="https://github.com/" target="_blank" rel="noopener noreferrer"> Lucas Matheus </a> </p>
</div>
</div>

<!-- Arquivos JS -->
<script src="assets/js/scripts.js"></script>
</body>
</html>