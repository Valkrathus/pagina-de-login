<div class="title">
    <button onClick="closeMenu()" class="button-primary-round button-close">
        <i class="fas fa-angle-left"></i>
    </button>
    <h1> Recuperar </h1>
</div>
<form action="." method="post" id="form-recuperar">

    <div class="form-field">
        <div class="form-icon">
            <i class="fas fa-envelope"></i>
        </div>
        <input
            type="email"
            name="form-recuperacao-email"
            id="recuperacao-email"
            placeholder="ex.: email@site.com"
            title="Deve seguir o formato nome@domínio.extensão do domínio, e ter no mínimo de 11 caracteres, ou um máximo de 35"
            minlength="11"
            maxlength="35"
            required
        >
    </div>

    <input type="submit" value="Confirmar" class="button-primary">
</form>