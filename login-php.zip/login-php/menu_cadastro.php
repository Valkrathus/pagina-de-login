<div class="title">
    <button onClick="closeMenu()" class="button-primary-round">
        <i class="fas fa-angle-left"></i>
    </button>
    <h1> Cadastro </h1>
</div>
<form action="." method="post" id="form-cadastro">

    <label for="cadastro-nome">
        Digite seu nome
        <div class="form-field">
            <div class="form-icon">
                <i class="fas fa-user"></i>
            </div>
            <input
                type="text"
                name="form-cadastro-nome"
                id="cadastro-nome"
                placeholder="ex: João da Silva"
                minlength="5"
                maxlength="50"
                pattern="[a-zA-Z ]{5,50}"
                title="Deve conter somente letras maiúsculas e minúsculas, e ter no mínimo 5 caracteres, ou um máximo de 50"
                required
            >
        </div>
    </label>

    <label for="cadastro-cpf">
        Digite seu CPF
        <div class="form-field">
            <div class="form-icon">
                <i class="fas fa-user"></i>
            </div>
            <input
                type="text"
                name="form-cadastro-cpf"
                id="cadastro-cpf"
                placeholder="ex: 999.999.999-99"
                minlength="11"
                maxlength="11"
                pattern="(\d{11})"
                title="Deve ser inserido no formato 00000000000"
                required
            >
        </div>
    </label>

    <label for="cadastro-email">
        Digite seu e-mail
        <div class="form-field">
            <div class="form-icon">
                <i class="fas fa-envelope"></i>
            </div>
            <input
                type="email"
                name="form-cadastro-email"
                id="cadastro-email"
                placeholder="ex: email@site.com"
                title="Deve seguir o formato nome@domínio.extensão do domínio, e ter no mínimo 11 caracteres, ou um máximo de 35"
                minlength="11"
                maxlength="35"
                required
            >
        </div>
    </label>

    <label for="cadastro-celular">
        Digite seu celular
        <div class="form-field">
            <div class="form-icon">
                <i class="fas fa-mobile-alt"></i>
            </div>
            <input
                type="text"
                name="form-cadastro-celular"
                id="cadastro-celular"
                placeholder="ex: (01)23456-7890"
                pattern="\d{10,11}"
                title="Deve seguir o formato 01234567890"
                minlength="10"
                maxlength="11"
                required
            >
        </div>
    </label>

    <label for="cadastro-senha">
        Digite sua senha
        <div class="form-field">
            <div class="form-icon">
                <i class="fas fa-unlock-alt"></i>
            </div>
            <input
                type="password"
                name="form-cadastro-senha"
                id="cadastro-senha"
                placeholder="**********"
                minlength="7"
                maxlength="25"
                pattern="(?=^.{7,25}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$"
                title = "Deve conter no mínimo uma letra maiúscula, uma minúscula, um número, um caractere especial, e ter no mínimo 7 caracteres, ou um máximo de 25"
                required
            >
        </div>
    </label>

    <input type="submit" value="Cadastrar" class="button-primary">
</form>