<?php include('header.php'); ?>

<div class="container-wrap">
    <div class="container-main">
        <div class="block-logo">
            <img src="assets/images/logo.png" alt="" class="logo">
        </div>
        <div class="block-form">
            <div id="menu-main">
                <button onClick="openMenu(this.id)" id="button-login" class="button-primary"> Acessar plataforma </button>
                <button onClick="openMenu(this.id)" id="button-cadastro" class="button-primary"> Criar conta </button>
                <button onClick="openMenu(this.id)" id="button-recuperacao" class="button-primary"> Recuperar senha </button>
            </div>
            <div id="menu-login">
                <?php include('menu_login.php'); ?>
            </div>
            <div id="menu-cadastro">
                <?php include('menu_cadastro.php'); ?>
            </div>
            <div id="menu-recuperacao">
                <?php include('menu_recuperacao.php'); ?>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>